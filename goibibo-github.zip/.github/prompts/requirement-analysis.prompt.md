---
description: "Analyze the live Goibibo Login module and extract verified functional requirements for the mobile + OTP and email + password flows"
name: "Goibibo Login Requirement Analysis"
argument-hint: "Specify which Login flow(s) to analyze, or provide already-known requirements to verify against the live site"
agent: "agent"
---

Act as a Senior QA Analyst and Business Analyst. Analyze the Goibibo Login module at `https://www.goibibo.com` and extract verified, implementation-ready functional requirements. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Scope to analyze:

> ${input:scope:Analyze both the mobile number + OTP flow and the email + password flow for Login}

## Analysis process

1. Locate the `Login` entry point on the live application (commonly a "Login / Sign up" trigger in the header) and open it.
2. Identify every distinct way a user can complete Login: mobile number + OTP, email + password, and any social login options visible. Note social login as out of scope unless the user explicitly requests it.
3. For each in-scope flow, observe and record:
   - Entry point (control name, location, trigger behavior)
   - Required and optional input fields, with visible format/length constraints
   - Client-side validation behavior (what triggers an inline error, and when)
   - Every visible error state and its exact message text
   - Success behavior: redirect target, confirmation shown, session/cookie indicators
   - Timing behavior: OTP resend cooldown, OTP expiry, retry/lockout limits, if observable
4. Do not submit real personal data, trigger a real OTP send to a real device, or attempt to bypass any security control during analysis.
5. Mark anything you cannot directly verify by observation as an assumption rather than presenting it as confirmed behavior.
6. Cross-check findings against any existing framework files, prior requirement notes, or test data already in the repository, and flag conflicts.

## Requirement quality rules

- State each requirement as a specific, testable statement, not a vague description.
- Keep requirements implementation-neutral — describe expected behavior, not Selenium/Pytest implementation detail.
- Separate functional requirements from UI/validation requirements from error-handling requirements.
- Use exact field labels and error text as observed, in quotes, so later prompts can build accurate assertions.
- Do not invent business rules, limits, or error text that were not directly observed or explicitly provided.

## Required output

Return only these sections, in this exact order:

## Application Context

State the module, URL, and flows in scope for this analysis.

## Flow Analysis

For each flow (Mobile Number + OTP, Email + Password), provide:
- Entry point
- Fields and constraints
- Validation rules
- Error states (exact message text where observed)
- Success behavior
- Timing/limit behavior (resend, expiry, lockout)

## Assumptions & Unverified Items

List every item marked `[UNVERIFIED — confirm on live site]` during analysis, with why it could not be confirmed.

## Final Requirement Summary

Summarize total requirements captured per flow, confidence level, and what should be confirmed manually before automation begins. Do not add sections outside this list.
