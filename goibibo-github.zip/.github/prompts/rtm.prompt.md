---
description: "Build a Requirements Traceability Matrix linking Goibibo Login requirements to user stories, test scenarios, test cases, and automation status"
name: "Goibibo Login RTM Generator"
argument-hint: "Provide requirement-analysis, user-story, test-scenario, and/or test-case output to trace"
agent: "agent"
---

Act as a Senior QA Lead. Build a Requirements Traceability Matrix (RTM) for the Goibibo Login module that links every requirement through to its automation status. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Source material available:

> ${input:source:Provide the output of requirement-analysis.prompt.md, user-story.prompt.md, test-scenario.prompt.md, and any generated test cases or test results}

## Process

1. Collect whatever source artifacts are available: requirements (from [Requirement Analysis](./requirement-analysis.prompt.md)), user stories (from [User Story Generator](./user-story.prompt.md)), test scenarios (from [Test Scenario Generator](./test-scenario.prompt.md)), and test cases/results (from [Test Designer](./test-designer.prompt.md), [Selenium Generator](./selenium-generator.prompt.md), or a Pytest run).
2. For each requirement, trace forward: which user story implements it, which scenario(s) test it, which test case(s)/automated test(s) exist, and its current automation and pass/fail status.
3. Flag any requirement with a broken trace — no story, no scenario, no test case, or no automation — as a coverage gap rather than omitting it.
4. Flag any scenario or test case that does not trace back to a requirement as orphaned, since it may indicate scope creep or an undocumented requirement.
5. Keep the matrix current to whatever inputs were actually supplied — do not invent requirement, story, or scenario IDs that were not provided.
6. Group the matrix by flow (Mobile Number + OTP, Email + Password) for readability.

## Required output

Return only these sections, in this exact order:

## RTM Scope

State which source artifacts were available and which were missing (e.g., "no test case IDs supplied — Automation Status left as Not Yet Automated for all rows").

## Traceability Matrix

Provide a table with these columns:

| Requirement ID | Requirement Summary | Flow | User Story ID | Scenario ID(s) | Test Case ID(s) | Automation Status | Last Result |
|---|---|---|---|---|---|---|---|

Automation Status values: `Not Yet Automated`, `Automated`, `Automated — Failing`, `Blocked`.
Last Result values: `Pass`, `Fail`, `Not Run`, `N/A`.

## Coverage Gaps

List every requirement, story, or scenario with a broken trace, and every orphaned scenario/test case with no traceable requirement. State `None identified` when there are no gaps.

## Final RTM Summary

Summarize total requirements, coverage percentage (requirements with a complete trace to an automated, passing test), and the highest-priority gaps to close next. Do not add sections outside this list.
