---
description: "Generate a complete production-ready Goibibo Login Selenium framework with Python, Selenium 4, Pytest, WebDriverManager, and POM"
name: "Goibibo Selenium Framework Generator"
argument-hint: "Describe additional Goibibo Login scenarios or generate the complete framework"
agent: "agent"
---

Act as a Selenium Automation Framework Architect and Selenium Expert Tester. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Generate a complete, production-ready Selenium Python automation framework for the Goibibo Login module:

- Application URL: `https://www.goibibo.com`
- Python: 3.11 or later
- Selenium: Selenium 4
- Test framework: Pytest
- Driver management: WebDriverManager
- Design: Page Object Model with reusable page components

Additional requested scenarios or constraints:

> ${input:feature:Generate the complete Goibibo Login framework covering mobile number + OTP and email + password flows}

Cover the module's core workflows unless the user explicitly narrows the scope:

- Valid login and invalid login validation for both mobile+OTP and email+password
- OTP request, entry, resend, cooldown, and expiry handling
- Email/password format and credential validation
- Error-state visibility and messaging for both flows
- Successful post-login redirect and session state
- Logout and re-login behavior
- Appropriate negative, boundary, and validation scenarios

## Workflow

1. Inspect the repository before making changes. Reuse existing structure and preserve unrelated user changes.
2. Create the complete framework rather than only a sample test. Use clear package boundaries and add `__init__.py` files where required.
3. Implement reusable page objects for the login entry point, the mobile+OTP flow, and the email+password flow. Add reusable components for shared login-modal behavior (e.g., tab switching between flows) when beneficial.
4. Add shared fixtures for browser creation, WebDriverManager setup, configurable browser and headless mode, base URL, logging, screenshots, and cleanup.
5. Add configuration and test-data utilities. Use environment variables for credentials, mobile numbers, and OTP values and provide `.env.example` placeholders without committing secrets.
6. Add focused Pytest scripts for the core workflows with descriptive names, meaningful assertions, and `smoke` and `regression` markers where appropriate.
7. Include positive, negative, validation, and boundary scenarios relevant to Goibibo's Login module.
8. Use explicit waits with Selenium expected conditions. Never use `time.sleep()`.
9. Add failure diagnostics, logging, screenshots, and an HTML or repository-standard test report without exposing sensitive data.
10. Run syntax checks, Pytest collection, and the relevant test suite when the environment permits. Fix issues caused by the generated changes.

## Implementation requirements

- Use Python 3.11 or later, Selenium 4, Pytest, and WebDriverManager.
- Follow PEP 8, use type hints where practical, and keep package imports explicit and reliable.
- Keep tests independent, deterministic, and safe to run repeatedly.
- Use stable Goibibo locators in this order: ID, Name, CSS selector, then XPath.
- Avoid brittle selectors based on layout, generated values, or fragile text.
- Keep test intent in test files and browser interactions in Page Object classes.
- Keep assertions in test scripts or assertion helpers, never in page classes.
- Use fixtures for browser lifecycle and shared setup or teardown.
- Avoid duplicated Selenium actions by placing genuinely reusable behavior in utilities.
- Use clear assertion messages that explain the expected and actual behavior.
- Ensure browser resources are closed even when a test fails.
- Keep generated code compatible with local, CI, and headless execution.
- Do not hardcode credentials, mobile numbers, OTPs, secrets, or mutable test data.

## Expected framework structure

Use this structure unless the repository already establishes a better equivalent:

```text
project-root/
|-- config/
|   |-- settings.py
|-- pages/
|   |-- base_page.py
|   |-- login_page.py
|   |-- components/
|   |   |-- otp_login_component.py
|   |   |-- email_login_component.py
|-- tests/
|   |-- conftest.py
|   |-- test_login_mobile_otp.py
|   |-- test_login_email_password.py
|-- utils/
|   |-- driver_factory.py
|   |-- waits.py
|   |-- logger.py
|   |-- screenshots.py
|   |-- test_data.py
|-- logs/
|-- screenshots/
|-- reports/
|-- .env.example
|-- pytest.ini
|-- requirements.txt
|-- README.md
```

Only create directories that are needed by the implementation, and follow existing repository conventions when they differ. If a different module is added later, extend `pages/`, `tests/`, and `utils/test_data.py` with new module-specific files rather than modifying the Login-specific ones.

## Expected output

## Required output

Return only these sections, in this exact order:

1. `Framework Structure`
2. `Page Objects`
3. `Test Scripts`
4. `Validation Report`
5. `Optimization Suggestions`
6. `Screenshots`

In `Framework Structure`, list every generated or updated file and its responsibility.
In `Page Objects`, summarize each page/component, its locators, and reusable actions, noting which flow (mobile+OTP or email+password) each belongs to.
In `Test Scripts`, summarize scenarios, markers, test data, and key assertions, grouped by flow.
In `Validation Report`, include commands and results for syntax, collection, linting, and tests, or state what could not run.
In `Optimization Suggestions`, include only actionable improvements and assumptions.
In `Screenshots`, document failure-screenshot behavior and paths, or state that no screenshots were generated. Do not add sections outside this list.
