---
description: "Run an end-to-end QA design, Selenium framework generation, implementation, and validation workflow for the Goibibo Login module"
name: "Master Goibibo Login QA"
argument-hint: "Provide additional Login requirements, existing framework scope, or validation constraints"
agent: "agent"
---

Act as a Senior QA Engineer, Selenium Automation Framework Architect, and Selenium Expert Tester. Analyze and automate the Goibibo Login module at `https://www.goibibo.com` using the existing workspace conventions and [Selenium and Pytest instructions](../selenium-instructions.md).

Additional requirements or constraints:

> ${input:requirements:Use the standard Goibibo Login module requirements covering mobile number + OTP and email + password flows, and the existing workspace framework}

## Required technology

- Python 3.11 or later
- Selenium 4
- Pytest
- WebDriverManager
- Page Object Model
- Explicit waits and stable locators
- Reusable fixtures, utilities, logging, screenshots, and reporting

## QA workflow

Use all relevant available workspace QA skills, agents, and prompts, including:

- [Requirement Analysis](./requirement-analysis.prompt.md)
- [User Story Generator](./user-story.prompt.md)
- [Test Scenario Generator](./test-scenario.prompt.md)
- [RTM Generator](./rtm.prompt.md)
- [Generate Test Scenarios](../skills/generate-test-scenarios/SKILL.md)
- [Generate Framework](../skills/generate-framework/SKILL.md)
- [Generate Page Object](../skills/generate-page-object/SKILL.md)
- [Generate Pytest Tests](../skills/generate-pytest-tests/SKILL.md)
- [Validate Selenium](../skills/validate-selenium/SKILL.md)
- [Validate POM](../skills/validate-pom/SKILL.md)
- [Validate Pytest](../skills/validate-pytest/SKILL.md)
- [Review Locators](../skills/review-locators/SKILL.md)
- [Debug Failures](../skills/debug-failures/SKILL.md)
- [Optimize Code](../skills/optimize-code/SKILL.md)

Follow this order:

1. Inspect the repository, existing framework, dependencies, tests, page objects, fixtures, configuration, and current user changes before editing.
2. Run [Requirement Analysis](./requirement-analysis.prompt.md) against the live Login module to establish verified requirements for both flows, unless verified requirements already exist.
3. Run [User Story Generator](./user-story.prompt.md) to convert those requirements into user stories with acceptance criteria.
4. Run [Test Scenario Generator](./test-scenario.prompt.md) to derive prioritized scenarios covering valid mobile+OTP login, valid email+password login, invalid mobile number, invalid/expired/incorrect OTP, invalid email format, incorrect password, empty-field submission, error-message, navigation, session, resend/cooldown, retry-limit, and relevant boundary or security-related cases. Do not assume unsupported application behavior.
5. Design a maintainable framework structure for Pages, Tests, Utilities, Data, Reports, configuration, fixtures, and reusable components. Preserve existing conventions when they are sound.
6. Implement the minimum complete production-ready framework needed for the Login module. Use a Login Page Object (with clear separation between the mobile+OTP flow and the email+password flow), base or shared page behavior where justified, reusable fixtures, externalized configuration, test data, logging, failure screenshots, and reporting.
7. Generate Pytest tests with independent setup, meaningful assertions, suitable markers, parametrization where useful, and no assertions in page classes.
8. Validate Python syntax, imports, test discovery, fixtures, locators, waits, POM boundaries, Pytest usage, maintainability, scalability, CI/headless readiness, and security.
9. Review locators using this preference order: ID, Name, CSS selector, then XPath. Verify uniqueness and resilience where HTML or runtime evidence is available.
10. Investigate any validation failure, exception, flaky behavior, or framework defect using logs, stack traces, screenshots, and execution flow. Separate confirmed root causes from hypotheses.
11. Optimize only where evidence supports the change. Avoid unrelated refactoring, duplicate abstractions, arbitrary sleeps, hardcoded secrets, and unsupported assumptions.
12. Run the narrowest useful checks, then broader tests when feasible. Report commands and results accurately; do not claim tests passed if they were not run.
13. Run [RTM Generator](./rtm.prompt.md) to trace every requirement through to its story, scenario, test case, and automation status, and surface any coverage gaps.

## Login coverage expectations

Cover, where supported by the application and requirements:

**Mobile number + OTP flow**
- Valid mobile number entry and correct OTP submission
- Invalid mobile number format (too short, too long, non-numeric)
- Incorrect OTP submission
- Expired OTP submission
- OTP resend and cooldown timer behavior
- Retry-limit or lockout behavior after repeated failed attempts

**Email + password flow**
- Valid email and password
- Invalid email format
- Incorrect password
- Empty email and/or password submission
- Password field masking and sensitive-data handling

**Shared behavior**
- Error message content, visibility, and dismissal or state behavior
- Login button and form submission behavior
- Navigation to the expected post-login page
- Browser refresh, back navigation, session state, and logout impact where relevant
- Headless and CI execution considerations

## Implementation rules

- Use explicit Selenium waits and expected conditions; never use `time.sleep()`.
- Keep locators and browser actions in page objects; keep workflow assertions in tests or assertion helpers.
- Prefer stable locators in the order ID, Name, CSS selector, then XPath.
- Use fixtures for WebDriverManager setup, browser lifecycle, browser selection, headless mode, configuration, logging, screenshots, and cleanup.
- Keep credentials, mobile numbers, OTPs, URLs, environment values, and test data configurable and free of committed secrets.
- Use clear test names, assertion messages, markers, and readable module structure.
- Keep generated code compatible with local execution, CI, and headless browsers.
- Preserve unrelated user changes and do not modify files outside the requested automation scope.
- If a different module is requested later, treat it as new scope rather than repurposing Login-specific pages, fixtures, or tests.

## Required output

Return only these sections, in this exact order:

## Test Scenarios

List prioritized Login-module scenarios with IDs, category, priority, preconditions, high-level steps, expected outcomes, and automation suitability. Group by flow (Mobile + OTP, Email + Password).

## Framework Structure

Show the generated or recommended directory tree and list each created or updated file with its responsibility.

## Python Code

Include the complete generated or updated Python framework code needed for the Login module, clearly grouped by file path. Include page objects, fixtures, tests, utilities, configuration, data, logging, and reporting code where implemented. Do not include code that was not generated or changed.

## Validation Report

Report syntax checks, imports, Pytest collection, relevant test commands, fixture checks, locator checks, POM checks, and execution results. Distinguish passed, failed, skipped, unavailable, and not-run checks.

## Risk Analysis

List confirmed and potential risks with severity, evidence, affected files or workflows, impact, and assumptions. Include locator, synchronization, test-data, environment, security, flakiness, CI, and scalability risks where relevant.

## Optimization Suggestions

Provide prioritized, actionable improvements for readability, reuse, maintainability, performance, reliability, framework quality, and future coverage. Include expected benefit and implementation effort.

## Final Output

Summarize what was generated, validated, and left unresolved. Include assumptions, required environment variables, test commands, artifacts such as screenshots or reports, and any remaining application-specific information needed. Do not add sections outside this list.
