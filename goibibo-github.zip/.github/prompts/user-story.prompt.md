---
description: "Convert verified Goibibo Login requirements into user stories with Given/When/Then acceptance criteria for the mobile + OTP and email + password flows"
name: "Goibibo Login User Story Generator"
argument-hint: "Provide requirement-analysis output, or describe the Login behavior to convert into user stories"
agent: "agent"
---

Act as a Senior QA Analyst and Product Analyst. Convert Goibibo Login requirements into user stories with acceptance criteria suitable for downstream test-scenario and RTM generation. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Requirements or context to convert:

> ${input:requirements:Provide the output of requirement-analysis.prompt.md, or describe the Login requirements to convert}

## Process

1. Read the supplied requirements (or the output of [Requirement Analysis](./requirement-analysis.prompt.md) when available) for both the mobile + OTP flow and the email + password flow.
2. For each distinct user-facing capability, write one user story in the standard format: "As a `<user type>`, I want `<capability>` so that `<benefit>`."
3. Write acceptance criteria for every story in Given/When/Then form, covering at minimum: the happy path, one negative case, and one error-message/state case.
4. Assign each story a unique ID (`US-01`, `US-02`, ...) and group stories by flow so they map cleanly to test scenarios later.
5. Do not invent acceptance criteria that the source requirements do not support — mark any criteria based on assumption rather than observed/stated requirement.
6. Keep each story small enough to map to one coherent set of test scenarios; split a story that bundles unrelated behavior.

## Story quality rules

- Every story must be testable — acceptance criteria should describe an observable, verifiable outcome.
- Avoid implementation detail (no locators, no Selenium/Pytest specifics) — stories describe user-facing behavior only.
- Use consistent user-type language across stories (e.g., "returning user," "first-time visitor") based on what the requirements support.
- Flag any requirement that has no clear story yet, rather than forcing a weak story around it.

## Required output

Return only these sections, in this exact order:

## Story Context

State the requirements source and the flows covered.

## User Stories

Group by flow (Mobile Number + OTP, Email + Password). For each story, provide the ID, the story statement, and Given/When/Then acceptance criteria.

## Acceptance Criteria Coverage Check

Confirm which requirements from the source map to a story, and list any requirement left uncovered with a reason.

## Final Story Summary

Summarize story counts per flow, coverage confidence, and any assumptions made. Do not add sections outside this list.
