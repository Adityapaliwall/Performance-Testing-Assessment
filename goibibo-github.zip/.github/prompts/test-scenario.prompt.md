---
description: "Generate a prioritized, numbered list of Goibibo Login test scenarios from user stories or requirements"
name: "Goibibo Login Test Scenario Generator"
argument-hint: "Provide user-story output, requirements, or describe the Login flow to generate scenarios for"
agent: "agent"
---

Act as a Senior QA Test Designer. Generate a comprehensive, prioritized list of Goibibo Login test scenarios using the workspace [Generate Test Scenarios](../skills/generate-test-scenarios/SKILL.md) skill. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Source material:

> ${input:source:Provide the output of user-story.prompt.md or requirement-analysis.prompt.md, or describe the Login behavior directly}

## Process

1. Read the supplied user stories or requirements for both the mobile + OTP flow and the email + password flow.
2. Apply the [Generate Test Scenarios](../skills/generate-test-scenarios/SKILL.md) skill's procedure and coverage criteria to derive scenarios.
3. Cover, per flow: positive, negative, boundary (OTP digit length, resend cooldown, retry/lockout limit, mobile number length, email/password length), UI/validation, and session behavior (already logged in, logout then re-login).
4. Prioritize every scenario as `P0` (critical smoke), `P1` (high-value regression), `P2` (important validation/edge), or `P3` (lower-risk/exploratory).
5. Number scenarios per flow with non-overlapping ID ranges (e.g., `TS-01`–`TS-19` for Mobile + OTP, `TS-20`–`TS-39` for Email + Password) so they stay traceable into test cases and the RTM.
6. Map each scenario to the source story ID it comes from, when a source story is available.
7. Do not generate Python code, locators, or detailed step-by-step test cases here — that belongs to [Test Designer](./test-designer.prompt.md) or [Selenium Generator](./selenium-generator.prompt.md).

## Required output

Return only these sections, in this exact order:

## Coverage Summary

Summarize scope, source material used, and scenario counts by priority and flow.

## Test Scenarios

Provide a table with these columns:

| ID | Flow | Priority | Category | Scenario | Source Story | Automation Candidate |
|---|---|---|---|---|---|---|

## Coverage Gaps

List any requirement or story with no corresponding scenario, and why. State `None identified` when there are no gaps.

Do not add sections outside this list.
