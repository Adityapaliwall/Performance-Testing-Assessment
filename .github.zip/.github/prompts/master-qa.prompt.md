---
description: "Run an end-to-end QA design, Selenium framework generation, implementation, and validation workflow for the SauceDemo Login module"
name: "Master SauceDemo Login QA"
argument-hint: "Provide additional Login requirements, existing framework scope, or validation constraints"
agent: "agent"
---

Act as a Senior QA Engineer, Selenium Automation Framework Architect, and Selenium Expert Tester. Analyze and automate the SauceDemo Login module at `https://www.saucedemo.com` using the existing workspace conventions and [Selenium and Pytest instructions](../selenium-instructions.md).

Additional requirements or constraints:

> ${input:requirements:Use the standard SauceDemo Login module requirements and existing workspace framework}

## Required technology

- Python 3.13
- Selenium 4
- Pytest
- WebDriverManager
- Page Object Model
- Explicit waits and stable locators
- Reusable fixtures, utilities, logging, screenshots, and reporting

## QA workflow

Use all relevant available workspace QA skills and agents, including:

- [Generate Test Scenarios](../skills/generate-test-scenarios/SKILL.md)
- [Generate Framework](../skills/generate-framework/SKILL.md)
- [Generate Page Object](../skills/generate-page-object/SKILL.md)
- [Generate Pytest Tests](../skills/generate-pytest-tests/SKILL.md)
- [Validate Selenium](../skills/validate-selenium/SKILL.md)
- [Validate POM](../skills/validate-pom/SKILL.md)
- [Validate Pytest](../skills/validate-pytest/SKILL.md)
- [Review Locators](../skills/review-locators/SKILL.md)
- [Debug Failures](../skills/debug-failures/SKILL.md)
- [Optimize Code](../skills/optimize-code/SKILL.md)

Follow this order:

1. Inspect the repository, existing framework, dependencies, tests, page objects, fixtures, configuration, and current user changes before editing.
2. Analyze the Login module and identify valid login, invalid credentials, locked-out user, empty fields, missing username, missing password, error-message, navigation, session, and relevant boundary or security-related scenarios. Do not assume unsupported application behavior.
3. Generate prioritized scenarios using P0 critical smoke, P1 high-value regression, P2 important validation or edge, and P3 lower-risk candidates.
4. Design a maintainable framework structure for Pages, Tests, Utilities, Data, Reports, configuration, fixtures, and reusable components. Preserve existing conventions when they are sound.
5. Implement the minimum complete production-ready framework needed for the Login module. Use a Login Page Object, base or shared page behavior where justified, reusable fixtures, externalized configuration, test data, logging, failure screenshots, and reporting.
6. Generate Pytest tests with independent setup, meaningful assertions, suitable markers, parametrization where useful, and no assertions in page classes.
7. Validate Python syntax, imports, test discovery, fixtures, locators, waits, POM boundaries, Pytest usage, maintainability, scalability, CI/headless readiness, and security.
8. Review locators using this preference order: ID, Name, CSS selector, then XPath. Verify uniqueness and resilience where HTML or runtime evidence is available.
9. Investigate any validation failure, exception, flaky behavior, or framework defect using logs, stack traces, screenshots, and execution flow. Separate confirmed root causes from hypotheses.
10. Optimize only where evidence supports the change. Avoid unrelated refactoring, duplicate abstractions, arbitrary sleeps, hardcoded secrets, and unsupported assumptions.
11. Run the narrowest useful checks, then broader tests when feasible. Report commands and results accurately; do not claim tests passed if they were not run.

## Login coverage expectations

Cover, where supported by the application and requirements:

- Valid standard-user login
- Invalid username and invalid password
- Username-only and password-only submission
- Empty form submission
- Locked-out user behavior
- Error message content, visibility, and dismissal or state behavior
- Password masking and sensitive-data handling
- Login button and form submission behavior
- Navigation to the expected post-login page
- Browser refresh, back navigation, session state, and logout impact where relevant
- Headless and CI execution considerations

## Implementation rules

- Use explicit Selenium waits and expected conditions; never use `time.sleep()`.
- Keep locators and browser actions in page objects; keep workflow assertions in tests or assertion helpers.
- Prefer stable locators in the order ID, Name, CSS selector, then XPath.
- Use fixtures for WebDriverManager setup, browser lifecycle, browser selection, headless mode, configuration, logging, screenshots, and cleanup.
- Keep credentials, URLs, environment values, and test data configurable and free of committed secrets.
- Use clear test names, assertion messages, markers, and readable module structure.
- Keep generated code compatible with local Windows execution, CI, and headless browsers.
- Preserve unrelated user changes and do not modify files outside the requested automation scope.

## Required output

Return only these sections, in this exact order:

## Test Scenarios

List prioritized Login-module scenarios with IDs, category, priority, preconditions, high-level steps, expected outcomes, and automation suitability.

## Framework Structure

Show the generated or recommended directory tree and list each created or updated file with its responsibility.

## Python Code

Include the complete generated or updated Python framework code needed for the Login module, clearly grouped by file path. Include page objects, fixtures, tests, utilities, configuration, data, logging, and reporting code where implemented. Do not include code that was not generated or changed.

## Validation Report

Report syntax checks, imports, Pytest collection, relevant test commands, fixture checks, locator checks, POM checks, and execution results. Distinguish passed, failed, skipped, unavailable, and not-run checks.

## Risk Analysis

List confirmed and potential risks with severity, evidence, affected files or workflows, impact, and assumptions. Include locator, synchronization, test-data, environment, security, flakiness, CI, and scalability risks where relevant.

## Optimization Suggestions

Provide prioritized, actionable improvements for readability, reuse, maintainability, performance, reliability, framework quality, and future coverage. Include expected benefit and implementation effort.

## Final Output

Summarize what was generated, validated, and left unresolved. Include assumptions, required environment variables, test commands, artifacts such as screenshots or reports, and any remaining application-specific information needed. Do not add sections outside this list.
