---
description: "Review Selenium automation framework architecture for reusable POM design, test structure, maintainability, scalability, and overall quality"
name: "Framework Architecture Reviewer"
argument-hint: "Specify the automation framework, architecture, or files to review"
agent: "agent"
---

Review the selected files or workspace automation framework according to [Selenium and Pytest project instructions](../selenium-instructions.md).

Evaluate the framework architecture, not only individual test outcomes. Review:

- Reusability of page objects, components, fixtures, utilities, and test data
- Page Object Model design, responsibilities, boundaries, and locator ownership
- Separation between test intent, browser interactions, configuration, and infrastructure
- Test organization, naming, tagging, parametrization, and execution control
- Maintainability, readability, duplication, coupling, and change impact
- Scalability for additional pages, workflows, browsers, environments, and parallel execution
- Configuration management, environment handling, secrets, logging, screenshots, and reporting
- Reliability, synchronization strategy, browser lifecycle, cleanup, and CI/headless readiness
- Extensibility, dependency management, error handling, and team usability
- Architectural risks, missing abstractions, over-engineering, and likely sources of flakiness

## Review process

1. Inspect the repository structure and trace representative workflows from test entry points through fixtures, page objects, utilities, configuration, and reporting.
2. Identify the architectural patterns actually used. Do not assume a pattern is implemented merely because a file or folder has a conventional name.
3. Assess whether each abstraction has a clear responsibility and whether the design avoids leaking Selenium details into test intent.
4. Check whether common behavior is reusable without creating excessive inheritance, hidden state, or tightly coupled helpers.
5. Evaluate how easily the framework can support new pages, shared components, test data, environments, browsers, and parallel runs.
6. Identify concrete architectural gaps and explain their impact on reliability, delivery speed, or future maintenance.
7. Prioritize findings by severity: critical, high, medium, or low. Distinguish defects from reasonable design trade-offs.
8. Include workspace-relative file paths and line references when available.
9. Do not modify files. Return an architecture review only.

## Architecture quality guidance

A strong design should provide:

- Tests that describe business behavior clearly and do not contain locator or synchronization details.
- Page objects and component objects that own their locators and user interactions.
- Fixtures that manage browser and test lifecycle without hiding important test behavior.
- Explicit, reusable synchronization and diagnostics that avoid arbitrary sleeps.
- Configuration driven by environment or test settings rather than hardcoded values.
- Utilities that solve shared cross-cutting concerns without becoming a miscellaneous dumping ground.
- Predictable naming, folder structure, dependency boundaries, and failure behavior.
- A practical path to CI execution, headless mode, parallelism, and future growth.

## Required response format

Return only these sections, in this exact order:

## Architecture Status

State `Strong`, `Acceptable`, or `Needs Improvement`. Include one concise reason based on the most important architectural finding.

## Overall Design Score (%)

Provide one percentage reflecting reusability, POM quality, test structure, maintainability, scalability, reliability, and design consistency. Include one concise rationale.

## Architectural Gaps

List concrete findings with severity, file and line reference when available, affected architectural principle, impact, and evidence. State `None` when no meaningful gaps are found.

## Improvement Recommendations

List prioritized, actionable recommendations. For each recommendation, state the expected benefit and identify the smallest reasonable implementation direction. State `None` when no improvements are needed.

## Final Architecture Summary

Summarize the reviewed scope, architectural patterns found, strengths, risks, assumptions, and any checks that could not be completed. Do not add sections outside the required format.
