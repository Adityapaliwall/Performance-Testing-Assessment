---
description: "Validate a Python Selenium automation framework for syntax, POM, Pytest, locators, structure, maintainability, and scalability"
name: "Selenium Framework Validator"
argument-hint: "Specify the Selenium framework, files, or generated automation to review"
agent: "agent"
---

Review the selected files or workspace Selenium framework according to [Selenium and Pytest project instructions](../selenium-instructions.md).

Validation scope:

- Python syntax, imports, and obvious runtime errors
- Selenium WebDriver best practices and reliable browser lifecycle management
- Page Object Model implementation and separation of responsibilities
- Pytest fixtures, test discovery, markers, parametrization, and assertions
- Locator quality, stability, accessibility, and maintainability
- Framework structure, configuration, utilities, logging, screenshots, and test data handling
- Security of credentials and environment-specific configuration
- Code readability, duplication, maintainability, scalability, and CI/headless readiness
- Missing tests, weak coverage, flaky behavior, and production-readiness risks

## Review process

1. Inspect the relevant files and nearby tests, fixtures, configuration, dependencies, and utilities before judging the framework.
2. Validate Python syntax and imports when the required tools or environment are available. Distinguish verified failures from issues inferred by inspection.
3. Check the complete execution path from test entry point through fixtures, page objects, utilities, browser setup, assertions, and teardown.
4. Identify concrete defects, compliance gaps, risks, and improvement opportunities. Do not report formatting preferences as issues unless they affect correctness or maintainability.
5. Prioritize issues by severity: critical, high, medium, or low.
6. Include file paths and line references for every concrete issue when available.
7. Consider both the current implementation and how the design will behave as the test suite grows.
8. Do not modify files. Return a review only.

## Rating guidance

Calculate the Overall Score as a percentage based on correctness, reliability, framework design, test quality, security, maintainability, and scalability. Apply judgment consistently and explain score-relevant risks in the issues or recommendations. A score of 100% should only be used when no meaningful issues or gaps are found.

## Required response format

Return only these sections, in this exact order:

## Pass/Fail Status

State `Pass` only when the framework is suitable for production use with no critical or high-severity issues. Otherwise state `Fail`. Include one concise reason.

## Overall Score (%)

Provide one percentage and one concise rationale.

## Issues Found

List concrete issues, each with severity, file and line reference when available, impact, and evidence. State `None` when no issues are found.

## Recommendations

List prioritized, actionable improvements. State `None` when no recommendations are needed.

## Final Data Summary

Summarize the reviewed scope, validation checks performed, test or command results, assumptions, and any checks that could not be run. Do not add sections outside the required format.
