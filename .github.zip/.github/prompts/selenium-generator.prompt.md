---
description: "Generate a complete production-ready SauceDemo Selenium framework with Python 3.13, Selenium 4, Pytest, WebDriverManager, and POM"
name: "SauceDemo Selenium Framework Generator"
argument-hint: "Describe additional SauceDemo scenarios or generate the complete framework"
agent: "agent"
---

Act as a Selenium Automation Framework Architect and Selenium Expert Tester. Follow [Selenium and Pytest project instructions](../selenium-instructions.md).

Generate a complete, production-ready Selenium Python automation framework for the SauceDemo application:

- Application URL: `https://www.saucedemo.com`
- Python: 3.13
- Selenium: Selenium 4
- Test framework: Pytest
- Driver management: WebDriverManager
- Design: Page Object Model with reusable page components

Additional requested scenarios or constraints:

> ${input:feature:Generate the complete SauceDemo framework and cover the core workflows}

Cover the application's core workflows unless the user explicitly narrows the scope:

- Valid login and invalid login validation
- Inventory page visibility and product information
- Product sorting by name and price
- Adding and removing products from the cart
- Cart contents and cart badge validation
- Checkout information validation and successful checkout completion
- Logout and session cleanup
- Appropriate negative, boundary, and validation scenarios

## Workflow

1. Inspect the repository before making changes. Reuse existing structure and preserve unrelated user changes.
2. Create the complete framework rather than only a sample test. Use clear package boundaries and add `__init__.py` files where required.
3. Implement reusable page objects for login, inventory, product details, cart, checkout information, checkout overview, and checkout completion. Add reusable components for navigation, product cards, and cart behavior when beneficial.
4. Add shared fixtures for browser creation, WebDriverManager setup, configurable browser and headless mode, base URL, logging, screenshots, and cleanup.
5. Add configuration and test-data utilities. Use environment variables for credentials and provide `.env.example` values or documented defaults for SauceDemo's public test account without committing secrets.
6. Add focused Pytest scripts for the core workflows with descriptive names, meaningful assertions, and `smoke` and `regression` markers where appropriate.
7. Include positive, negative, validation, and boundary scenarios relevant to SauceDemo.
8. Use explicit waits with Selenium expected conditions. Never use `time.sleep()`.
9. Add failure diagnostics, logging, screenshots, and an HTML or repository-standard test report without exposing sensitive data.
10. Run syntax checks, Pytest collection, and the relevant test suite when the environment permits. Fix issues caused by the generated changes.

## Implementation requirements

- Use Python 3.13, Selenium 4, Pytest, and WebDriverManager.
- Follow PEP 8, use type hints where practical, and keep package imports explicit and reliable.
- Keep tests independent, deterministic, and safe to run repeatedly.
- Use stable SauceDemo locators in this order: ID, Name, CSS selector, then XPath.
- Avoid brittle selectors based on layout, generated values, or fragile text.
- Keep test intent in test files and browser interactions in Page Object classes.
- Keep assertions in test scripts or assertion helpers, never in page classes.
- Use fixtures for browser lifecycle and shared setup or teardown.
- Avoid duplicated Selenium actions by placing genuinely reusable behavior in utilities.
- Use clear assertion messages that explain the expected and actual behavior.
- Ensure browser resources are closed even when a test fails.
- Keep generated code compatible with local, Windows PowerShell, CI, and headless execution.
- Do not hardcode credentials, secrets, or mutable test data.

## Expected framework structure

Use this structure unless the repository already establishes a better equivalent:

```text
project-root/
|-- config/
|   |-- settings.py
|-- pages/
|   |-- base_page.py
|   |-- login_page.py
|   |-- inventory_page.py
|   |-- product_page.py
|   |-- cart_page.py
|   |-- checkout_page.py
|   |-- components/
|-- tests/
|   |-- conftest.py
|   |-- test_login.py
|   |-- test_inventory.py
|   |-- test_cart.py
|   |-- test_checkout.py
|   |-- test_logout.py
|-- utils/
|   |-- driver_factory.py
|   |-- waits.py
|   |-- logger.py
|   |-- screenshots.py
|   |-- test_data.py
|-- logs/
|-- screenshots/
|-- reports/
|-- .env.example
|-- pytest.ini
|-- requirements.txt
|-- README.md
```

Only create directories that are needed by the implementation, and follow existing repository conventions when they differ.

## Expected output

## Required output

Return only these sections, in this exact order:

1. `Framework Structure`
2. `Page Objects`
3. `Test Scripts`
4. `Validation Report`
5. `Optimization Suggestions`
6. `Screenshots`

In `Framework Structure`, list every generated or updated file and its responsibility.
In `Page Objects`, summarize each page/component, its locators, and reusable actions.
In `Test Scripts`, summarize scenarios, markers, test data, and key assertions.
In `Validation Report`, include commands and results for syntax, collection, linting, and tests, or state what could not run.
In `Optimization Suggestions`, include only actionable improvements and assumptions.
In `Screenshots`, document failure-screenshot behavior and paths, or state that no screenshots were generated. Do not add sections outside this list.
