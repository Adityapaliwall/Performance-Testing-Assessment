---
name: generate-pytest-tests
description: 'Generate production-ready Selenium Python Pytest test classes using Page Object Model, reusable fixtures, assertions, parametrization, and automation best practices. Use when creating or extending UI automation tests.'
argument-hint: 'Describe the workflow, feature, page objects, test data, and expected behavior to automate'
user-invocable: true
---

# Generate Pytest Tests

Generate production-ready Selenium Python Pytest test class(es) for the requested workflow or feature. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Creating new Selenium Pytest test cases.
- Extending coverage for an existing Page Object Model framework.
- Automating positive, negative, validation, boundary, smoke, or regression scenarios.
- Converting a manual web workflow into maintainable UI tests.

## Procedure

1. Read the user's requirements, expected behavior, available page objects, base page, fixtures, configuration, test data, markers, and nearby tests.
2. Identify the workflow, preconditions, test data, user actions, expected outcomes, error states, and cleanup requirements.
3. Reuse existing page objects, components, fixtures, helpers, assertion conventions, and marker names. Do not recreate browser interactions already owned by a page object.
4. Map each scenario to page-object methods. Keep raw Selenium locators and browser interactions out of test classes.
5. Choose independent test boundaries. Use fixtures for browser lifecycle, setup, teardown, authentication, and shared dependencies according to the repository's established scope.
6. Use parametrization for equivalent scenarios with different data. Keep test data externalized or sourced from existing data utilities when possible.
7. Write clear test methods with descriptive names, focused behavior, meaningful assertions, and useful assertion messages.
8. Include positive, negative, validation, and boundary coverage when requested or when the behavior requires it.
9. Apply existing Pytest markers such as `smoke` and `regression` consistently. Do not invent markers when the repository already defines a convention.
10. Check test isolation, repeatability, ordering independence, cleanup, and compatibility with local, CI, headless, and parallel execution.
11. Validate syntax, imports, fixture names, page-object methods, parametrization, and assertion logic against the available repository context.

## Implementation rules

- Generate one or more complete Python test classes as requested.
- Use Pytest conventions: `test_*.py` modules, `Test*` classes, and `test_*` methods.
- Use the existing `conftest.py` fixtures instead of creating duplicate WebDriver setup.
- Use Page Object Model methods for all page interaction.
- Keep assertions in test classes or dedicated assertion helpers, never in page objects.
- Use explicit waits through page objects or established wait helpers; never use `time.sleep()`.
- Avoid hardcoded credentials, secrets, environment-specific URLs, and mutable test data.
- Use type hints where consistent with the existing codebase.
- Include only imports required by the generated tests and existing framework APIs.
- Do not generate page objects, fixtures, utilities, configuration, dependency files, or documentation unless the user explicitly requests them.
- Do not include Markdown fences, commentary, headings, test plans, or explanations.
- If a required page-object method or fixture is missing, use the repository's established API when possible and keep the generated test syntactically valid. Do not silently invent a conflicting framework abstraction.

## Test quality checks

Before responding, verify that:

- Each test has a clear precondition, workflow, and expected result.
- Tests are independent and do not rely on execution order or state from another test.
- Assertions validate observable application behavior rather than implementation details.
- Page objects, fixtures, and utilities are reused appropriately.
- Parametrized data has stable IDs or readable case names where useful.
- Failure messages identify the expected behavior and relevant data.
- No `time.sleep()`, raw locator, hardcoded secret, or duplicate browser setup is present.
- Imports, fixture references, markers, and page-object calls are consistent with the repository.
- The output contains only complete Python test class(es).

## Required output

Return only the complete Selenium Python Pytest test class(es) as valid Python source code. Do not add any other content.
