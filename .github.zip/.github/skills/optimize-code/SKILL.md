---
name: optimize-code
description: 'Review and optimize Selenium Python automation code for readability, reusability, maintainability, performance, and best practices. Use when identifying code smells, duplicate logic, inefficient browser operations, or framework improvement opportunities.'
argument-hint: 'Provide the Selenium code, framework files, performance concern, or scope to optimize'
user-invocable: true
---

# Optimize Code

Review the selected Selenium Python automation code or framework and provide evidence-based optimization recommendations. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Refactoring Selenium page objects, tests, fixtures, or utilities.
- Removing duplicate browser actions and repeated setup.
- Improving readability, reuse, maintainability, performance, or test stability.
- Preparing automation code for larger suites, CI, headless mode, or parallel execution.

## Procedure

1. Inspect the selected code and its surrounding call sites, page objects, tests, fixtures, utilities, configuration, dependencies, and documentation.
2. Identify the existing architecture and preserve conventions that are already effective.
3. Find code smells such as duplication, oversized methods, unclear names, excessive nesting, hidden state, broad exception handling, dead code, magic values, and mixed responsibilities.
4. Check Page Object Model boundaries, locator ownership, reusable components, assertion placement, fixture responsibilities, and dependency direction.
5. Check Selenium efficiency and reliability: repeated navigation, unnecessary element lookups, arbitrary sleeps, ineffective waits, stale references, excessive browser sessions, and avoidable network or DOM operations.
6. Check test-suite efficiency: fixture scopes, parametrization, setup duplication, test isolation, parallel safety, data setup, teardown, logging, screenshots, and report generation.
7. Check maintainability: configuration externalization, stable locator strategy, focused utilities, typing, naming, documentation, error context, and compatibility with CI/headless execution.
8. Rank each recommendation by impact and effort. Prefer small, safe, incremental improvements over speculative abstractions or rewrites.
9. Distinguish confirmed code smells from context-dependent risks. Include workspace-relative file paths and line references when available.
10. Do not modify files. Return only the required optimization report.

## Optimization criteria

- Improve clarity without changing intended behavior.
- Prefer reusable page actions and focused components over duplicated Selenium code.
- Keep tests expressive and keep browser details in page objects.
- Use explicit waits and expected conditions instead of `time.sleep()`.
- Prefer stable locators in this order: ID, Name, CSS selector, then XPath.
- Avoid premature caching of WebElements when the DOM can re-render.
- Reuse browser and fixture setup safely without leaking state between tests.
- Externalize configuration, credentials, and test data.
- Preserve useful diagnostics while avoiding sensitive data and excessive logging.
- Avoid introducing unnecessary inheritance, generic utility dumping grounds, or abstractions that increase coupling.
- Consider execution time, flakiness, memory, parallelism, and CI artifact size.

## Priority guidance

- `High`: Clear correctness, stability, security, or significant performance improvement.
- `Medium`: Meaningful maintainability, reuse, reliability, or moderate performance improvement.
- `Low`: Readability, consistency, or minor optimization with limited risk.

## Required output

Return only these sections, in this exact order:

## Optimization Findings

Summarize the reviewed scope, strengths, code smells, duplication, performance risks, and maintainability observations. State `None identified` when no findings are present.

## Optimization Recommendations

List prioritized recommendations with priority, location, current concern, proposed improvement, expected benefit, implementation effort, and behavior risk. State `None` when no recommendations are needed.

## Final Optimization Summary

Summarize the highest-value improvements, expected effect on readability, reuse, maintainability, performance, and stability, plus any assumptions or checks that could not be completed. Do not add sections outside this list.
