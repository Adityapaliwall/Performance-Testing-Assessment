---
name: generate-page-object
description: 'Generate production-ready Selenium Python Page Object classes with maintainable locators, reusable actions, explicit waits, and POM best practices. Use when creating or refactoring a page object for a web page, feature, or workflow.'
argument-hint: 'Describe the page, URL, elements, and user actions for the Page Object'
user-invocable: true
---

# Generate Page Object

Generate one production-ready Selenium Python Page Object class for the requested page, feature, or workflow. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## Procedure

1. Read the user's page description, available HTML or selectors, existing page objects, base page, wait helpers, configuration, and project naming conventions.
2. Identify the page responsibility, required elements, user actions, navigation transitions, dynamic states, and values that the page object must expose.
3. Reuse the existing base page, wait abstraction, locator type, logging style, and import conventions. Do not introduce a duplicate framework abstraction.
4. Define locators inside the page object. Prefer stable selectors in this order: ID, Name, CSS selector, then XPath. Use semantic or accessible attributes where available.
5. Implement small, reusable methods representing user actions or page-state queries. Keep browser interaction details inside the page object.
6. Use explicit Selenium waits and expected conditions for visibility, presence, clickability, text, URL, or state changes. Never use `time.sleep()`.
7. Return page objects for navigation transitions when the action changes pages. Return values or state from query methods so callers can perform assertions.
8. Keep assertions, test data, credentials, test-specific business logic, and test orchestration outside the page object.
9. Add type hints where practical, clear names, and concise docstrings only where they clarify non-obvious behavior.
10. Check the generated class for valid Python syntax, consistent imports, locator correctness, duplicate actions, synchronization gaps, and compatibility with the existing framework.

## Implementation rules

- Generate exactly one complete Python Page Object class.
- Include only imports required by the class and its existing framework dependencies.
- Use a constructor that accepts the existing WebDriver type or follows the repository's established base-page constructor.
- Prefer constants or class-level locator definitions over repeated literal selectors.
- Keep locators maintainable and avoid layout-dependent selectors, generated IDs, and brittle absolute XPath.
- Use the repository's logging and wait helpers when they exist; otherwise use Selenium's `WebDriverWait` and expected conditions directly.
- Do not add Pytest tests, fixtures, utilities, README content, dependency files, or explanations.
- Do not include Markdown fences, commentary, headings, or text before or after the class.
- If required information is missing, make the smallest reasonable assumption in code rather than returning multiple alternatives.

## Completion checks

Before responding, verify that:

- The output contains only one Python Page Object class.
- The class has no assertions.
- No `time.sleep()` or hardcoded secrets are present.
- Locators are defined in the class and follow the preferred stability order.
- Actions use explicit waits where synchronization is needed.
- Navigation and query methods return useful page objects or values.
- The code is syntactically valid and consistent with the repository's POM conventions.

## Required output

Return only the complete Page Object class as valid Python source code. Do not add any other content.
