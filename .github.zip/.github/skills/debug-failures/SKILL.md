---
name: debug-failures
description: 'Analyze Selenium Python automation failures using code, logs, stack traces, screenshots, and execution flow to identify root causes, flaky behavior, and framework issues. Use when debugging UI automation failures.'
argument-hint: 'Provide the failing test, error, stack trace, logs, screenshots, or execution details'
user-invocable: true
---

# Debug Failures

Analyze Selenium Python and Pytest automation failures using the available code, logs, stack traces, screenshots, test output, and execution flow. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Debugging failed Selenium or Pytest tests.
- Investigating exceptions, assertion failures, flaky behavior, timeouts, and stale elements.
- Finding framework, fixture, configuration, synchronization, locator, data, or logic defects.
- Diagnosing CI-only, headless-only, intermittent, or performance-related failures.

## Procedure

1. Inspect the failing test, page object, fixture, utility, configuration, dependency, and nearby call sites.
2. Read the complete error message, stack trace, logs, screenshots, timestamps, retry history, and environment details before forming a conclusion.
3. Reconstruct the execution flow from fixture setup through browser creation, navigation, page actions, waits, assertions, teardown, and report capture.
4. Classify the failure as an exception, assertion mismatch, locator defect, synchronization issue, stale state, fixture or lifecycle issue, environment or dependency issue, data issue, performance issue, or logic defect.
5. Identify the smallest root cause that explains the observed behavior. Do not stop at a symptom such as `TimeoutException` when the underlying locator, page state, redirect, overlay, or wait condition is responsible.
6. Check common Selenium failure modes: dynamic content, stale elements, hidden or disabled elements, overlays, frames, windows, alerts, redirects, session expiry, browser-driver mismatch, and incorrect URL or credentials.
7. Check Pytest and framework issues: fixture scope, cleanup, ordering, shared state, parametrization, parallel execution, page-object responsibilities, and configuration.
8. Compare repeated runs and environments. Label a failure flaky only when evidence indicates non-deterministic behavior.
9. Separate verified facts from hypotheses and specify the smallest additional evidence needed to resolve uncertainty.
10. Recommend a permanent fix, validation steps, and any temporary mitigation. Do not modify files.

## Debugging standards

- Prefer explicit waits and Selenium expected conditions over `time.sleep()`.
- Evaluate locators in this order: ID, Name, CSS selector, then XPath.
- Keep locators and browser interactions in page objects; keep workflow assertions in tests or assertion helpers.
- Verify WebDriver lifecycle and cleanup even when setup or test execution fails.
- Check Python, Selenium, browser, driver, Pytest, WebDriverManager, URL, credentials, and headless configuration compatibility.
- Consider timing, page state, data isolation, external services, and CI resource constraints.
- Never repeat passwords, tokens, cookies, or other sensitive values in the report.
- Include workspace-relative file paths and line references when available.

## Required output

Return only these sections, in this exact order:

## Issue Summary

State the affected test or workflow, observed failure, severity, reproducibility, and current status. State `No issue identified` only when the available evidence does not demonstrate a defect.

## Root Cause Analysis

Explain the confirmed root cause, supporting evidence, execution path, and contributing factors. Clearly label unresolved hypotheses and missing evidence.

## Impact

Describe the affected tests, workflows, environments, CI behavior, reliability, performance, data integrity, and maintainability impact.

## Fix Recommendations

Provide prioritized, actionable permanent fixes with file and line references when available, validation steps, and temporary mitigations separately when useful.

## Final Debug Report

Summarize the evidence reviewed, reproduction or validation performed, confirmed findings, remaining risks, assumptions, and information still required. Do not add sections outside this list.
