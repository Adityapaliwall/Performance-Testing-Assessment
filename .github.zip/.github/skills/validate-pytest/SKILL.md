---
name: validate-pytest
description: 'Review Selenium Python Pytest implementations for fixtures, test structure, assertions, parametrization, maintainability, isolation, and Pytest best practices. Use when validating or reviewing UI automation tests.'
argument-hint: 'Provide the Pytest files, fixtures, configuration, or test suite to review'
user-invocable: true
---

# Validate Pytest

Review the selected Selenium Python Pytest implementation and related test framework files. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Reviewing generated or existing Selenium Pytest tests.
- Validating fixtures, test organization, and test execution behavior.
- Finding weak assertions, parametrization defects, order dependencies, or duplicate setup.
- Checking whether a test suite is maintainable and suitable for CI or parallel execution.

## Procedure

1. Inspect test modules, test classes, `conftest.py`, fixtures, page objects, utilities, configuration, markers, dependencies, and nearby tests.
2. Validate test discovery naming, imports, fixture references, parametrization syntax, marker registration, and collection behavior when the environment permits.
3. Trace each representative test from fixture setup through page-object actions, assertions, cleanup, and failure handling.
4. Check fixture scope, lifecycle, dependency direction, teardown behavior, browser cleanup, state isolation, and compatibility with parallel execution.
5. Check test structure, naming, single responsibility, workflow clarity, ordering independence, repeatability, and duplication.
6. Check that tests use Page Object Model methods for browser interaction and keep raw locators, Selenium commands, and synchronization details out of test intent.
7. Check assertion quality: observable behavior, meaningful messages, complete expected outcomes, negative paths, and absence of assertions hidden in page objects.
8. Check parametrization for readable IDs, stable data, appropriate scope, coverage, and clean failure diagnosis.
9. Check markers, smoke/regression organization, configuration, logging, screenshots, reporting, environment handling, secrets, CI/headless execution, and maintainability.
10. Distinguish confirmed defects from risks, assumptions, and missing evidence. Include workspace-relative file paths and line references when available.
11. Do not modify files. Return only the required findings, issues, and recommendations.

## Validation criteria

- Test modules and functions follow Pytest discovery conventions.
- Fixtures have appropriate scope and reliably clean up browser and test state.
- Tests are independent, deterministic, repeatable, and safe to run in any order.
- Browser interactions are delegated to page objects or focused helpers.
- Assertions validate user-visible or business-relevant behavior and provide useful failure context.
- Parametrization is used where it reduces duplication without hiding scenario intent.
- Markers are registered, consistently applied, and useful for execution selection.
- No arbitrary `time.sleep()` or duplicated WebDriver setup is used.
- Credentials, secrets, environment values, and mutable test data are externalized.
- Logging, screenshots, and reports support diagnosis without exposing sensitive data.
- The suite can run locally, headlessly, in CI, and with parallel execution where supported.

## Severity guidance

- `Critical`: Prevents collection or execution, invalidates core results, or compromises test safety.
- `High`: Causes broad failures, severe flakiness, unsafe shared state, or major coverage loss.
- `Medium`: Reduces reliability, clarity, reuse, isolation, or maintainability.
- `Low`: Limited-impact quality or consistency improvement.

## Required output

Return only these sections, in this exact order:

## Findings

Summarize the reviewed scope, strengths, confirmed defects, risks, and validation checks performed. State `None identified` when no findings are present.

## Issues

List concrete issues with severity, file and line reference when available, evidence, impact, and whether each issue is confirmed or inferred. State `None identified` when no issues are found.

## Recommendations

List prioritized, actionable improvements with expected benefits and validation steps. State `None` when no recommendations are needed. Do not add sections outside this list.
