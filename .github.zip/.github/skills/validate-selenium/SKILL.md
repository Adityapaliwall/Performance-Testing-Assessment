---
name: validate-selenium
description: 'Review Selenium Python automation code and frameworks for syntax, Selenium best practices, locator strategy, waits, Pytest usage, maintainability, and framework quality. Use when validating generated or existing UI automation.'
argument-hint: 'Provide the Selenium code, framework files, test output, or repository scope to validate'
user-invocable: true
---

# Validate Selenium

Review the selected Selenium Python automation code or framework. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Validating generated Selenium Python automation.
- Reviewing an existing Selenium and Pytest framework.
- Checking a framework before CI, merge, release, or production use.
- Finding locator, wait, fixture, POM, maintainability, and reliability problems.

## Procedure

1. Inspect the relevant Python files, page objects, tests, fixtures, utilities, configuration, dependencies, reports, and nearby documentation.
2. Validate Python syntax, imports, test discovery conventions, fixture references, and obvious runtime defects when the available environment permits.
3. Check Selenium usage, WebDriver lifecycle, browser cleanup, explicit waits, expected conditions, dynamic content handling, frames, windows, alerts, redirects, and session state.
4. Review locator strategy. Prefer stable locators in this order: ID, Name, CSS selector, then XPath. Flag brittle layout selectors, generated values, absolute XPath, and unstable text selectors.
5. Review Page Object Model boundaries, locator ownership, separation of test intent from browser interaction, navigation return types, component reuse, and assertion placement.
6. Review Pytest usage, fixtures, scopes, parametrization, markers, test isolation, ordering independence, assertion quality, data handling, and parallel-execution risks.
7. Review framework structure, duplication, naming, configuration, logging, screenshots, reporting, security, CI/headless readiness, dependency management, maintainability, and scalability.
8. Distinguish verified defects from risks, assumptions, and missing evidence. Include workspace-relative file paths and line references whenever available.
9. Assign a score based on correctness, reliability, locator quality, synchronization, POM design, test quality, maintainability, security, and scalability. A score of 100% requires no meaningful issues.
10. Do not modify files. Return only the required validation report sections.

## Validation criteria

- No syntax or import errors in the reviewed scope.
- Tests use Pytest conventions and discoverable names.
- Fixtures reliably create and close browser sessions.
- Tests are isolated, repeatable, and safe for CI or headless execution.
- Page objects own locators and browser actions; tests own workflow intent and assertions.
- Locators are stable and maintainable.
- Explicit waits replace arbitrary sleeps; `time.sleep()` is treated as a defect unless exceptionally justified.
- Credentials, secrets, and environment-specific data are externalized.
- Logging and failure screenshots provide useful diagnostics without exposing sensitive values.
- Framework abstractions are reusable without excessive inheritance, coupling, or utility duplication.

## Severity guidance

- `Critical`: Prevents execution, compromises security, or invalidates core results.
- `High`: Causes broad failures, severe flakiness, unsafe behavior, or major maintenance risk.
- `Medium`: Reduces reliability, reuse, clarity, coverage, or scalability.
- `Low`: Limited-impact improvement or minor quality gap.

## Required output

Return only these sections, in this exact order:

## Findings

Summarize the validated scope, strengths, confirmed defects, risks, and checks performed. State `None identified` when no findings are present.

## Score (%)

Provide one overall percentage and a concise rationale. Include a short category breakdown for correctness, Selenium practices, Pytest/POM, maintainability, and framework quality.

## Issues

List concrete issues with severity, file and line reference when available, evidence, impact, and whether the issue is confirmed or inferred. State `None identified` when no issues are found.

## Recommendations

List prioritized, actionable improvements with expected benefits and validation steps. State `None` when no recommendations are needed. Do not add sections outside this list.
