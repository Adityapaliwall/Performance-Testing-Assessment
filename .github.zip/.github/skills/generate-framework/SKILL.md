---
name: generate-framework
description: 'Design a production-ready Selenium Python automation framework structure with Pages, Tests, Utilities, Data, Reports, configuration, and scalable architecture recommendations. Use when planning or standardizing a Selenium and Pytest framework.'
argument-hint: 'Describe the application, technology constraints, existing repository, or framework requirements'
user-invocable: true
---

# Generate Framework Structure

Design the folder structure and architecture for a maintainable Selenium Python automation framework. Use the existing repository conventions when available and follow [Selenium and Pytest project instructions](../../selenium-instructions.md).

## When to Use

- Starting a Selenium Python and Pytest framework.
- Standardizing an existing automation repository.
- Planning reusable Page Object Model architecture.
- Defining boundaries for tests, utilities, data, configuration, and reports.
- Preparing a framework for CI, headless execution, parallelism, and team development.

## Procedure

1. Inspect the existing repository structure, Python version, dependencies, tests, page objects, fixtures, configuration, and reporting conventions when they are available.
2. Extract the application type, browser requirements, environments, authentication model, test scope, CI needs, reporting expectations, and parallel-execution requirements from the user's request.
3. Decide whether to preserve the existing structure or propose a migration-friendly structure. Do not rename or move existing areas without explaining the architectural reason.
4. Define clear boundaries for:
   - `pages/` for Page Object Model classes and reusable page components
   - `tests/` for test intent, workflows, markers, and assertions
   - `utils/` for genuinely shared browser, wait, logging, screenshot, and helper behavior
   - `data/` for externalized test data and safe test fixtures
   - `reports/` for generated test reports and artifacts
   - `config/` for environment and execution configuration
   - `conftest.py` for Pytest fixtures and lifecycle management
5. Design the dependency direction so tests can use pages, fixtures, data, and utilities without creating circular dependencies or leaking infrastructure details into test intent.
6. Recommend a Page Object Model strategy, including base page responsibilities, page boundaries, component objects, locator ownership, navigation return types, and assertion placement.
7. Include practical support for browser and driver management, explicit waits, headless mode, environment configuration, logging, failure screenshots, reporting, CI, and optional parallel execution.
8. Keep the design proportional to the application. Avoid speculative layers, generic utility dumping grounds, unnecessary inheritance, and duplicated configuration.
9. Identify assumptions, trade-offs, migration concerns, and any requirements that need clarification.
10. Do not create or modify project files. Return only the framework structure, folder design, and architecture recommendations.

## Architecture quality criteria

- Tests express business behavior and keep Selenium implementation details in page objects or components.
- Page objects own locators and reusable browser actions but contain no test assertions.
- Utilities have focused responsibilities and are not used as a miscellaneous code dump.
- Test data and configuration are externalized and do not contain secrets.
- Fixtures control browser lifecycle, isolation, cleanup, and shared setup predictably.
- Explicit waits replace arbitrary sleeps and support stable synchronization.
- Reports and screenshots are easy to locate and safe to publish in CI artifacts.
- The structure can grow to support more pages, workflows, browsers, environments, and contributors.
- Dependencies remain understandable, acyclic, and easy to test.

## Required output

Return only these sections, in this exact order:

## Framework Structure

Show the recommended directory tree. Include only relevant files and folders, with one-line responsibilities for each important entry.

## Folder Design

Explain the purpose, ownership, allowed dependencies, and contents of `pages/`, `tests/`, `utils/`, `data/`, `reports/`, `config/`, fixtures, and project-level configuration files.

## Architecture Recommendations

Provide prioritized recommendations for POM boundaries, reusable components, fixtures, waits, locators, data management, logging, screenshots, reporting, environment configuration, CI, parallelism, and maintainability. Include trade-offs and migration notes where relevant.

Do not add code, implementation files, test cases, or sections outside this list.
