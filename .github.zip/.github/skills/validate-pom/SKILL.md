---
name: validate-pom
description: 'Review Selenium Python Page Object Model implementations for structure, reusability, maintainability, locator management, separation of concerns, and POM best practices. Use when validating or reviewing page objects and related framework code.'
argument-hint: 'Provide the page objects, framework files, or POM implementation to review'
user-invocable: true
---

# Validate POM

Review the selected Selenium Python Page Object Model implementation and related framework files. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Reviewing newly generated or modified page objects.
- Checking whether a Selenium framework follows POM best practices.
- Finding locator, synchronization, coupling, duplication, and responsibility problems.
- Assessing whether page objects are reusable and maintainable as the suite grows.

## Procedure

1. Inspect all selected page objects and relevant base pages, components, fixtures, tests, utilities, configuration, and nearby call sites.
2. Trace representative workflows from test methods through page-object methods and browser interactions.
3. Check class responsibilities, page boundaries, navigation transitions, component reuse, inheritance, and dependency direction.
4. Check that locators are owned by the appropriate page or component and are stable, readable, and maintainable. Prefer ID, Name, CSS selector, then XPath.
5. Check synchronization for explicit waits and expected conditions. Flag arbitrary sleeps, hidden timing assumptions, and duplicated wait logic.
6. Check separation of concerns: page objects should own locators and browser actions; tests should own workflow intent and assertions; fixtures should own lifecycle and setup.
7. Check method design, return types, state queries, duplication, hidden side effects, mutable state, exception handling, logging, and test-data leakage.
8. Evaluate maintainability and scalability for additional pages, shared components, browsers, environments, CI, headless execution, and parallel tests.
9. Identify concrete evidence with workspace-relative file paths and line references when available. Separate verified problems from risks or recommendations.
10. Do not modify files. Return only the requested findings, issues, and recommendations.

## Review criteria

- Page objects have one clear page or component responsibility.
- Locators are centralized, stable, descriptive, and owned by the correct object.
- Browser actions are reusable and do not contain test-specific assertions.
- Query methods return values or states for tests to assert.
- Navigation methods return the appropriate page object when the page changes.
- Explicit waits are used for dynamic state and actions; `time.sleep()` is absent.
- Tests do not contain raw locators or duplicated Selenium interactions.
- Page objects do not contain credentials, mutable test data, or test orchestration.
- Shared behavior uses focused composition or a justified base class rather than unnecessary inheritance.
- Logging and exceptions add useful context without hiding failures or exposing secrets.
- The design remains understandable and practical as coverage grows.

## Severity guidance

- `Critical`: The POM is unusable, unsafe, or prevents reliable execution.
- `High`: A major design or synchronization problem causes broad failures, severe flakiness, or significant maintenance cost.
- `Medium`: A localized issue reduces reuse, clarity, reliability, or scalability.
- `Low`: A minor improvement with limited current impact.

## Required output

Return only these sections, in this exact order:

## Findings

Summarize verified strengths and weaknesses in the POM implementation. Include file and line references when available. State `None identified` when no findings are present.

## Issues

List concrete issues with severity, location, evidence, affected POM principle, and impact. Separate confirmed defects from inferred risks. State `None identified` when no issues are found.

## Recommendations

List prioritized, actionable improvements with the expected benefit and smallest practical implementation direction. State `None` when no recommendations are needed. Do not add sections outside this list.
