---
name: review-locators
description: 'Analyze Selenium locators for reliability, uniqueness, maintainability, selector stability, and best-practice usage with ID, Name, CSS, and XPath. Use when reviewing or optimizing page-object locators.'
argument-hint: 'Provide Selenium locators, page objects, HTML snippets, or the framework files to review'
user-invocable: true
---

# Review Locators

Analyze the selected Selenium locators and their surrounding Page Object Model code. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Reviewing locators in Selenium page objects.
- Diagnosing `NoSuchElementException`, timeout, stale-element, or ambiguous-element failures.
- Replacing brittle or unstable selectors.
- Standardizing locator strategy across an automation framework.

## Procedure

1. Inspect each locator in context, including the page object, relevant HTML or DOM evidence, action method, wait condition, and test usage when available.
2. Determine what element the locator is intended to identify and whether it is unique in the relevant page state.
3. Evaluate selector stability against dynamic IDs, generated classes, layout changes, localization, text changes, responsive markup, repeated components, and DOM re-rendering.
4. Apply the preferred strategy in this order: ID, Name, CSS selector, then XPath. Use the first option that is stable, unique, semantic, and available.
5. Prefer semantic and accessible attributes such as stable IDs, names, labels, roles, and dedicated test attributes when they are part of the application contract.
6. Flag absolute XPath, positional XPath, excessive ancestor traversal, styling-only classes, generated values, broad selectors, partial text matches, and selectors that depend on DOM order.
7. Check whether the locator is centralized in the owning page object or component and whether it is reused consistently without duplication.
8. Check whether the associated action uses an appropriate explicit wait and whether the element can become stale, hidden, covered, disabled, or replaced.
9. Assess maintainability, readability, uniqueness, failure diagnosis, cross-browser behavior, and resilience to expected UI changes.
10. Recommend an optimized selector only when there is enough evidence. Clearly label assumptions when HTML or runtime uniqueness cannot be verified.
11. Do not modify files. Return only the required locator review sections.

## Locator quality criteria

- The selector identifies exactly the intended element in the required page state.
- The selector uses stable attributes and avoids incidental styling or layout details.
- ID is preferred when stable and unique; Name is preferred when appropriate and stable; CSS is preferred for reliable compound conditions; XPath is a last resort.
- The selector remains understandable to another test engineer.
- Dynamic collections use a stable parent, component boundary, or reliable child attribute rather than a fixed index.
- Locators are owned by the relevant page object or component.
- Waits match the required element state and are not replaced by `time.sleep()`.
- Selector recommendations do not expose credentials, tokens, personal data, or sensitive DOM values.

## Severity guidance

- `Critical`: Locator cannot identify the required element or creates unsafe false positives.
- `High`: Locator is broadly brittle, non-unique, or likely to cause frequent failures.
- `Medium`: Locator works currently but has meaningful maintainability or resilience risk.
- `Low`: Minor clarity, consistency, or optimization improvement.

## Required output

Return only these sections, in this exact order:

## Locator Findings

Summarize the reviewed locator scope, strengths, uniqueness evidence, and stability assessment. State `None identified` when no findings are present.

## Issues

List concrete issues with severity, file and line reference when available, current locator, failure risk, and evidence. State `None identified` when no issues are found.

## Optimization Recommendations

For each recommendation, include the preferred locator strategy, optimized selector when supported by evidence, expected benefit, and required wait or HTML change. State `None` when no recommendations are needed. Do not add sections outside this list.
