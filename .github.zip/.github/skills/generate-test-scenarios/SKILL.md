---
name: generate-test-scenarios
description: 'Generate comprehensive prioritized Selenium automation test scenarios for functional, UI, positive, negative, boundary, and end-to-end application flows. Use when turning requirements into automation coverage.'
argument-hint: 'Describe the application, feature, workflow, URL, or requirements for scenario design'
user-invocable: true
---

# Generate Test Scenarios

Generate comprehensive Selenium automation test scenarios from the supplied application requirements, workflow, user story, page behavior, or existing repository context. Follow the workspace Selenium and Pytest instructions in [selenium-instructions.md](../../selenium-instructions.md) when they apply.

## When to Use

- Converting application requirements into UI automation coverage.
- Planning Selenium and Pytest smoke or regression suites.
- Identifying missing positive, negative, validation, boundary, or end-to-end coverage.
- Prioritizing automation candidates by business risk and user impact.

## Procedure

1. Inspect the supplied requirements, application context, existing tests, page objects, fixtures, and documentation when available.
2. Identify users, roles, workflows, business rules, page states, inputs, outputs, dependencies, and failure conditions.
3. Derive scenarios across functional behavior, UI behavior, validation, positive flows, negative flows, boundary values, session behavior, and end-to-end journeys.
4. Include navigation, refresh, back/forward behavior, dynamic content, loading states, error messages, recovery, and cleanup when relevant.
5. Consider test data setup, data dependencies, duplicate data, empty data, invalid data, special characters, limits, and safe teardown.
6. Prioritize every scenario using:
   - `P0` - Critical smoke path; blocks core usage or release confidence.
   - `P1` - High-value regression path; important business behavior or common failure risk.
   - `P2` - Important edge, validation, UI, or recovery coverage.
   - `P3` - Lower-risk, exploratory, compatibility, or deferred automation candidate.
7. Remove duplicate scenarios while preserving distinct risks and clear failure diagnosis.
8. Identify scenarios suitable for Selenium UI automation and note when unit, API, integration, or manual coverage would be more efficient.
9. Map scenarios to likely Page Object Model pages or components without writing page-object code or test code.
10. State assumptions and coverage gaps only within the required scenario output. Do not invent unsupported business rules.

## Coverage criteria

Ensure the scenario set considers, where applicable:

- Functional workflows and business rules
- UI controls, labels, content, navigation, visibility, enabled state, and state changes
- Required-field, format, length, range, cross-field, and message validation
- Valid, invalid, empty, null, duplicate, boundary, and special-character data
- Authentication, authorization, session expiry, timeout, logout, and access control
- End-to-end workflows across multiple pages or system boundaries
- Browser, viewport, responsive, headless, and environment considerations
- Synchronization, dynamic content, overlays, frames, windows, alerts, and redirects
- Failure recovery, retry, refresh, interruption, and cleanup behavior
- Isolation, repeatability, parallel execution, external dependencies, and flakiness risks

## Scenario quality rules

- Make each scenario independently understandable and testable.
- Use clear scenario names that describe behavior and expected outcome.
- Include concise preconditions, data needs, high-level steps, and expected result.
- Prioritize business and technical risk rather than generating a large unranked list.
- Do not include real credentials, secrets, personal data, or production-sensitive values.
- Use stable, application-focused language suitable for later implementation with Pytest and POM.
- Do not generate Python code, locators, page classes, fixtures, or detailed test-case scripts.
- Do not include Markdown code fences or explanations outside the required sections.

## Required output

Return only these sections, in this exact order:

## Coverage Summary

Summarize the scope, assumptions, critical workflows, and overall coverage categories. Include counts by priority when practical.

## Test Scenarios

Provide a table with these columns:

| ID | Priority | Category | Scenario | Preconditions | High-Level Steps | Expected Outcome | Automation Candidate | POM Area |
|---|---|---|---|---|---|---|---|---|

Use unique IDs, clear priorities, and concise but implementation-ready scenario descriptions.

## Coverage Gaps

List missing requirements, unsupported assumptions, risks, or recommended non-UI coverage. State `None identified` when no gaps are found.

Do not add sections outside this list.
