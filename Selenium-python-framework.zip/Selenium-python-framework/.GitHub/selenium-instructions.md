# Selenium Python Framework — Global Instructions

These instructions apply to every prompt, agent, and skill in this repo. GitHub Copilot must follow them for all generated code and documents.

## Tech Stack
- **Language:** Python 3.10+
- **Automation:** Selenium WebDriver 4.x
- **Test Runner:** Pytest
- **Design Pattern:** Page Object Model (POM)
- **Reporting:** pytest-html (or Allure if configured)
- **Waits:** Explicit waits only (`WebDriverWait` + `expected_conditions`). Never use `time.sleep()` except as a last-resort fallback, and always comment why.
- **Locators:** Prefer, in order: `id` > `name` > `css selector` > `xpath`. Avoid brittle absolute XPath.

## Parameterization (important)
This framework must stay reusable across applications and modules — it is not hardcoded to one site.
- Every prompt/agent/skill takes `{application_name}`, `{application_url}`, and `{module_name}` as inputs.
- Current working values (set per session):
  - `application_name`: Goibibo
  - `application_url`: https://www.goibibo.com
  - `module_name`: Login
- To switch modules later, just re-invoke the relevant prompt with a new `{module_name}` — do not rewrite the instructions/skills.

## Folder Structure
```
.GitHub/
  selenium-instructions.md
  prompts/        → user-triggered slash commands (one per workflow phase)
  agents/         → personas Copilot adopts to do the work
  skills/         → reusable capabilities agents call internally
tests/
  pages/          → Page Object classes, one file per page/screen
  test_cases/     → Pytest test files, one file per module
  utils/          → driver setup, config, helpers
  data/           → test data (JSON/YAML/CSV), no hardcoded secrets
reports/          → generated test summaries, defect reports
```

## Naming Conventions
- Page classes: `{Module}Page` (e.g. `LoginPage`)
- Test files: `test_{module}_{flow}.py` (e.g. `test_login_email.py`, `test_login_otp.py`)
- Test functions: `test_{scenario_in_snake_case}`
- Locators: `UPPER_SNAKE_CASE` constants at the top of each Page class

## Code Quality Rules
- No hardcoded credentials, phone numbers, or OTPs in code — pull from `tests/data/` or environment variables.
- Every Page Object method returns either `self` (for chaining) or the next expected Page Object.
- Every test must be independent — no test should depend on another test's execution order.
- Assertions live only in test files, never inside Page Objects.
- Use `pytest.fixture` for driver setup/teardown (function or session scope as appropriate).

## Output Format Rules (for all prompts/agents/skills below)
- Always state which `{application_name}` and `{module_name}` the output is for at the top.
- Use Markdown tables for test cases/scenarios so they're easy to scan and convert to a POM later.
- Flag any assumption made about the live site's actual behavior explicitly, since flows should be confirmed against the real site before finalizing.
