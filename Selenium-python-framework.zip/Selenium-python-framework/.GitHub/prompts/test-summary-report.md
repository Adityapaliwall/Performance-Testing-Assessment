---
mode: agent
description: Summarize a full test execution run for a module into a report
---

# Test Summary Report Prompt

## Purpose
Summarize the outcome of running all test cases for `{module_name}` of `{application_name}`, for sharing with the team/session lead.

## Inputs
- Pytest run output (or `pytest-html` report)
- Any defect reports filed during this run

## Instructions to Copilot
1. Invoke `master-qa` to pull together results across both flows (Mobile+OTP, Email+Password).
2. Compute pass/fail/skip counts and pass rate.
3. List any filed defects with their IDs and severity.
4. Call out flaky tests separately from genuine failures (a test that passed on rerun without code changes is flaky, not a defect).

## Output Format
```
## Test Summary Report — {application_name} / {module_name}
**Run Date:**
**Total Test Cases:** 
**Passed:** | **Failed:** | **Skipped:** | **Pass Rate:** 

### By Flow
| Flow | Total | Passed | Failed |
|------|-------|--------|--------|
| Mobile + OTP | | | |
| Email + Password | | | |

### Defects Filed
| ID | Severity | Test Case | Status |
|----|----------|-----------|--------|

### Flaky Tests (not filed as defects)
- 

### Recommendation
(Ready to sign off / needs re-run / blocked on defect DEF-XX)
```
