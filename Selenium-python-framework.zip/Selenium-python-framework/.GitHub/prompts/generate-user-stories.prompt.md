---
mode: agent
description: Convert requirement analysis output into user stories with acceptance criteria
---

# Generate User Stories Prompt

## Purpose
Turn the requirement analysis for `{module_name}` of `{application_name}` into user stories the `test-designer` agent can turn into test scenarios.

## Inputs
- Output of `requirement-analysis.prompt.md`
- `module_name`: Login
- `application_name`: Goibibo

## Instructions to Copilot
1. Invoke the `master-qa` agent, which delegates to `test-designer`.
2. For every flow identified in the requirement analysis (mobile+OTP, email+password), write one or more user stories in standard format.
3. Each story must include Given/When/Then acceptance criteria covering both the happy path and at least one negative case.
4. Group stories by flow so they map cleanly to future test files (`test_login_email.py`, `test_login_otp.py`).

## Output Format
```
## User Stories — {application_name} / {module_name}

### Flow: Mobile Number + OTP
**US-01: As a returning user, I want to log in using my mobile number and OTP so that I can access my bookings.**
- Acceptance Criteria:
  - Given I am on the login page, when I enter a valid 10-digit mobile number and request OTP, then an OTP field appears.
  - Given a valid OTP is entered, when I submit, then I am redirected to my account/home page.
  - Given an invalid/expired OTP is entered, when I submit, then an inline error is shown and I am not logged in.

### Flow: Email + Password
**US-02: As a returning user, I want to log in with email and password so that I can access my account without OTP.**
- Acceptance Criteria:
  - ...
```

## Next Step
Feed this output into `generate-test-scenarios.prompt.md`.
