---
mode: agent
description: Expand test scenarios into detailed step-by-step test cases, then generate Selenium+Pytest code
---

# Generate Test Cases Prompt

## Purpose
Expand each test scenario for `{module_name}` of `{application_name}` into a detailed, executable test case, then hand off to code generation.

## Inputs
- Output of `generate-test-scenarios.prompt.md`
- `selenium-instructions.md` (global conventions)

## Instructions to Copilot
1. Invoke `master-qa`, which delegates to `test-designer` for detailed steps, then to `selenium-generator` for code, using the `generate-test-scenarios`, `generate-page-object`, and `generate-pytest-tests` skills in that order.
2. For every scenario ID from the previous step, write:
   - Preconditions
   - Numbered steps (user actions)
   - Test data used
   - Expected result
3. After all test cases are documented, generate:
   - `tests/pages/login_page.py` (Page Object, if not already present — else update it)
   - `tests/test_cases/test_login_email.py`
   - `tests/test_cases/test_login_otp.py`
4. Run the `selenium-validator` agent (via `validate-pom` and `validate-pytest` skills) on the generated code before presenting it as final.

## Output Format
```
## Test Cases — {application_name} / {module_name}

### TS-01: Login with valid mobile number and correct OTP
- Preconditions: User is on the Goibibo homepage, not logged in
- Steps:
  1. Click "Login / Sign up"
  2. Enter valid 10-digit mobile number
  3. Click "Get OTP"
  4. Enter correct OTP
  5. Click "Submit" / "Verify"
- Test Data: mobile_number = <from tests/data/login_data.json>
- Expected Result: User is redirected to account/home page, name/greeting visible
```
Followed by the generated `.py` files, each in its own code block with the file path as a comment on line 1.

## Next Step
Use `defect-report.md` to log any failures found during execution, and `test-summary-report.md` once a run is complete.
