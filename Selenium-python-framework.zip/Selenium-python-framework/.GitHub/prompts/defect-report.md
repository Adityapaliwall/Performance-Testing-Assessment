---
mode: agent
description: Generate a standardized defect report from a failed test case
---

# Defect Report Prompt

## Purpose
Turn a failed test execution for `{module_name}` of `{application_name}` into a clear, reproducible defect report.

## Inputs
- Failing test ID (e.g., TS-03) and its Pytest output/stack trace
- Screenshot or DOM snapshot at time of failure, if captured

## Instructions to Copilot
1. Invoke the `debugger` agent to inspect the failure: assertion mismatch, element not found, timeout, or unexpected redirect.
2. Distinguish between a **real application defect** and a **flaky/locator issue in the test itself** — if it's the latter, route it back to `selenium-validator` instead of writing a defect report.
3. Only file a defect report when the failure reflects genuine unexpected application behavior.

## Output Format
```
## Defect Report — {application_name} / {module_name}

**Defect ID:** DEF-<sequential number>
**Linked Test Case:** TS-XX
**Severity:** Critical / High / Medium / Low
**Environment:** Browser, OS, Goibibo URL/build if known

**Title:** <one-line summary>

**Steps to Reproduce:**
1.
2.
3.

**Expected Result:**
**Actual Result:**
**Evidence:** (screenshot path / console log / stack trace excerpt)
**Notes:** (e.g., "reproducible only on first attempt" / "intermittent")
```

## Next Step
Add filed defects to `test-summary-report.md` for the run.
