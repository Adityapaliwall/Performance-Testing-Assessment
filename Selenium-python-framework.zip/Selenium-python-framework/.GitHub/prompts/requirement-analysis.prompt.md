---
mode: agent
description: Analyze a live web application's module and extract functional requirements
---

# Requirement Analysis Prompt

## Purpose
Extract functional requirements for `{module_name}` of `{application_name}` by inspecting the live application, so downstream prompts (user stories, scenarios, test cases) have a grounded source of truth instead of assumptions.

## Inputs
- `application_name`: Goibibo
- `application_url`: https://www.goibibo.com
- `module_name`: Login

## Instructions to Copilot
1. Invoke the `framework-architect` agent to browse `{application_url}` and locate the `{module_name}` entry point (e.g., the "Login / Sign up" trigger, usually in the top nav).
2. Identify and document every distinct way a user can complete `{module_name}`:
   - Mobile number + OTP
   - Email + password (if offered)
   - Any social login options visible (Google/Facebook) — note but mark out-of-scope unless asked
3. For each flow, capture:
   - Entry point (button/link, and where it appears)
   - Required input fields and their validation rules (format, length, required/optional)
   - Visible error states (invalid number, wrong OTP, expired OTP, wrong password, etc.)
   - Success behavior (redirect target, confirmation shown, session/cookie set)
   - Any resend-OTP / timer / retry-limit behavior
4. Do not guess at behavior you can't observe — mark it `[UNVERIFIED — confirm on live site]` rather than inventing it.

## Output Format
```
## Requirement Analysis — {application_name} / {module_name}

### Flow 1: <name>
- Entry point:
- Fields:
- Validations:
- Error states:
- Success behavior:
- Notes / unverified items:

### Flow 2: <name>
...
```

## Next Step
Feed this output into `generate-user-stories.prompt.md`.
