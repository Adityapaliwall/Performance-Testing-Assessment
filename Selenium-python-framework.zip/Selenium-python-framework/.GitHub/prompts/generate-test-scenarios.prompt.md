---
mode: agent
description: Convert user stories into a structured list of test scenarios (titles only, no steps yet)
---

# Generate Test Scenarios Prompt

## Purpose
Produce a complete, numbered list of test scenarios for `{module_name}` of `{application_name}`, covering positive, negative, boundary, and UI/validation cases — before writing detailed steps.

## Inputs
- Output of `generate-user-stories.prompt.md`

## Instructions to Copilot
1. Invoke `master-qa`, which delegates scenario generation to `test-designer`, using the `generate-test-scenarios` skill.
2. Cover both flows in scope: Mobile Number + OTP, and Email + Password.
3. Include, at minimum, these categories per flow:
   - Positive (valid credentials → success)
   - Negative (invalid/blank/malformed input)
   - Boundary (min/max length mobile number, OTP digit count/expiry)
   - Security-adjacent UI checks (password masking, OTP field type, rate-limiting/resend timer)
   - Session behavior (already-logged-in redirect, logout then re-login)
4. Number scenarios so they can be traced 1:1 into `generate-test-cases.prompt.md`.

## Output Format
```
## Test Scenarios — {application_name} / {module_name}

### Flow: Mobile Number + OTP
| ID | Scenario | Category |
|----|----------|----------|
| TS-01 | Login with valid mobile number and correct OTP | Positive |
| TS-02 | Login attempt with invalid mobile number format | Negative |
| TS-03 | Login attempt with incorrect OTP | Negative |
| TS-04 | OTP expires before entry | Boundary |
| TS-05 | Resend OTP respects cooldown timer | Boundary |
...

### Flow: Email + Password
| ID | Scenario | Category |
|----|----------|----------|
| TS-10 | Login with valid email and password | Positive |
...
```

## Next Step
Feed this output into `generate-test-cases.prompt.md`.
