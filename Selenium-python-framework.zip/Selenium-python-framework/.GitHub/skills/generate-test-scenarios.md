---
skill: generate-test-scenarios
used-by: test-designer
---

# Skill: Generate Test Scenarios

## What it does
Given user stories (with Given/When/Then acceptance criteria) for `{module_name}`, produces a complete numbered scenario table split by flow and category.

## Input
- User stories output
- List of flows in scope (e.g., Mobile + OTP, Email + Password)

## Logic
1. For each acceptance criterion, generate at least one Positive scenario.
2. For each field with validation rules, generate Negative scenarios: empty, too short, too long, wrong format/type.
3. For each field with a defined limit (OTP digit count, resend timer, retry attempts), generate a Boundary scenario at the limit and just past it.
4. Add Session-behavior scenarios: already logged in → redirected away from login; logout → login again works.
5. Add UI/security-adjacent scenarios: password field masked, OTP field numeric-only, error messages don't leak whether a mobile number/email is registered (if applicable).
6. Assign sequential IDs per flow (TS-01, TS-02... for Mobile+OTP; TS-10, TS-11... for Email+Password) so ranges don't collide.

## Output
A Markdown table per flow: `ID | Scenario | Category`.
