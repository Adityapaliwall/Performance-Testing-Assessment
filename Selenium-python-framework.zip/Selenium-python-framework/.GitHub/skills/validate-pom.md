---
skill: validate-pom
used-by: selenium-validator
---

# Skill: Validate POM

## What it does
Checks a Page Object class against Page Object Model conventions.

## Checks
- [ ] Class named `{Module}Page`
- [ ] Locators declared as class-level constants, `UPPER_SNAKE_CASE`
- [ ] No assertions anywhere in the class (`assert` keyword should not appear)
- [ ] Every method name is a verb phrase describing a user action
- [ ] Methods return `self` or the next Page Object, not raw WebElements
- [ ] `__init__` accepts `driver` and stores a `WebDriverWait` instance
- [ ] No direct `driver.find_element` calls outside of the locator constants + wait pattern
- [ ] No business logic that belongs in a test (e.g., deciding pass/fail) lives in the Page Object

## Output
Pass/fail per check, with the specific line(s) flagged if failing.
