---
skill: review-locators
used-by: selenium-validator, debugger
---

# Skill: Review Locators

## What it does
A focused, deeper pass specifically on locator robustness — used both during validation and when the `debugger` agent triages a "locator not found" failure.

## Checks
- [ ] Priority order respected: `id` > `name` > `css selector` > `xpath`
- [ ] No absolute/brittle XPath (e.g., `/html/body/div[3]/div[2]/...`) — relative, attribute-based XPath only when XPath is required
- [ ] No locators built from dynamically-generated attributes (auto-incrementing IDs, hashed class names) unless no stable alternative exists
- [ ] Locators for elements inside iframes or shadow DOM are flagged explicitly, since they need extra handling
- [ ] Locators disambiguate correctly when Goibibo's page has multiple similar elements (e.g., "Login" appears in both header and a modal)

## When called by `debugger`
1. Re-locate the failing element on the live/current page structure.
2. Determine if the locator broke because the DOM changed, or because it was never robust to begin with.
3. Recommend a corrected locator and note which priority tier it falls into.

## Output
List of locators reviewed, pass/fail per check, and corrected locator suggestions where needed.
