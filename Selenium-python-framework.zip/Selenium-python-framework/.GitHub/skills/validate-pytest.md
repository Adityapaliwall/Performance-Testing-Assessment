---
skill: validate-pytest
used-by: selenium-validator
---

# Skill: Validate Pytest Structure

## What it does
Checks generated test files for Pytest best practices and independence.

## Checks
- [ ] Every test function starts with `test_` and has a descriptive, snake_case name
- [ ] Every test has the corresponding TS-ID referenced in a comment for traceability
- [ ] Tests use the shared `driver` fixture, not their own setup/teardown
- [ ] No test depends on the execution order or state left by another test
- [ ] Test data is loaded via `data_loader`, never hardcoded inline
- [ ] Each test has exactly one clear assertion focus (splitting unrelated checks into separate tests where needed)
- [ ] Negative-case tests assert on the specific expected error, not a generic "test passed" check
- [ ] Markers (`@pytest.mark.otp_login` / `@pytest.mark.email_login`) applied so flows can be run selectively

## Output
Pass/fail per check, with specific fixes suggested inline.
