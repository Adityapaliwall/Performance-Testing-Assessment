---
skill: generate-pytest-tests
used-by: selenium-generator
---

# Skill: Generate Pytest Tests

## What it does
Produces Pytest test functions from detailed test cases, calling only Page Object methods.

## Input
- Detailed test cases (preconditions, steps, test data, expected result)
- The relevant Page Object(s)

## Logic
1. One test file per flow: `test_login_email.py`, `test_login_otp.py`.
2. One test function per test case ID, named `test_{scenario_in_snake_case}` with the TS ID in a comment above it for traceability.
3. Use a shared `driver` fixture from `tests/utils/conftest.py` (function-scoped, handles setup/teardown).
4. Load test data via a helper (e.g., `load_test_data("login_data.json")`) — never inline.
5. Structure: Arrange (navigate + page object) → Act (perform steps) → Assert (expected result only).
6. Negative-case tests assert on the specific error message/state, not just "something went wrong."

## Output template
```python
# tests/test_cases/test_login_otp.py
import pytest
from tests.pages.login_page import LoginPage
from tests.utils.data_loader import load_test_data

data = load_test_data("login_data.json")

# TS-01: Login with valid mobile number and correct OTP
def test_login_valid_mobile_and_otp(driver):
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.enter_mobile_number(data["valid_mobile"])
    login_page.click_get_otp()
    login_page.enter_otp(data["valid_otp"])
    login_page.click_submit()
    assert login_page.is_logged_in(), "Expected user to be logged in after valid OTP"

# TS-03: Login attempt with incorrect OTP
def test_login_incorrect_otp(driver):
    login_page = LoginPage(driver)
    login_page.open_login()
    login_page.enter_mobile_number(data["valid_mobile"])
    login_page.click_get_otp()
    login_page.enter_otp(data["invalid_otp"])
    login_page.click_submit()
    assert login_page.get_error_message() == data["expected_invalid_otp_error"]
```
