---
skill: generate-framework
used-by: framework-architect
---

# Skill: Generate Framework (Scaffolding)

## What it does
Creates the base folder/file scaffolding the first time the framework runs, or adds what's missing for a new module.

## Logic
1. Check for existing `tests/` folder. If absent, create:
   ```
   tests/
     pages/__init__.py
     test_cases/__init__.py
     utils/__init__.py
     utils/conftest.py       # driver fixture (setup/teardown)
     utils/data_loader.py    # loads JSON/YAML test data
     data/
   requirements.txt          # selenium, pytest, pytest-html, webdriver-manager
   pytest.ini                # test discovery + markers config
   ```
2. `conftest.py` must use `webdriver-manager` (or an existing driver-management convention in the repo) rather than hardcoded driver paths.
3. For a new `{module_name}`, only add `tests/pages/{module}_page.py`, `tests/data/{module}_data.json`, and empty test file stubs — never touch existing modules' files.
4. `pytest.ini` should register markers per flow (e.g., `@pytest.mark.otp_login`, `@pytest.mark.email_login`) so runs can be filtered.

## Constraints
- Idempotent — running this again for the same module should not duplicate or overwrite existing files.
