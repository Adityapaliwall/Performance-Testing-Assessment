---
skill: validate-selenium
used-by: selenium-validator
---

# Skill: Validate Selenium Usage

## What it does
Checks wait strategy and Selenium API usage across generated code (Page Objects and tests).

## Checks
- [ ] Zero occurrences of `time.sleep()` (or clearly commented exception with justification)
- [ ] Every element interaction is preceded by an appropriate `expected_conditions` wait (`visibility_of_element_located`, `element_to_be_clickable`, etc. — matched to the action, e.g. don't use `visibility_of` before a `.click()`)
- [ ] A single shared `WebDriverWait` timeout convention is used (no scattered magic numbers)
- [ ] Driver is quit/closed in a fixture teardown, not manually inside test bodies
- [ ] No use of deprecated Selenium 3 syntax (e.g. `find_element_by_id`) — Selenium 4 `find_element(By.ID, ...)` only
- [ ] Browser options (headless/sandbox flags) are centralized in `conftest.py`, not duplicated per test

## Output
Pass/fail per check, with specific fixes suggested inline.
