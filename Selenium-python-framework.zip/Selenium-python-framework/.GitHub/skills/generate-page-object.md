---
skill: generate-page-object
used-by: selenium-generator
---

# Skill: Generate Page Object

## What it does
Produces or extends a Page Object class for `{module_name}` following POM conventions.

## Input
- Detailed test cases (for the actions/fields needed)
- Field labels/locator hints from `requirement-analysis` output

## Logic
1. Class name: `{Module}Page` (e.g., `LoginPage`).
2. Declare locators as class-level constants, `UPPER_SNAKE_CASE`, using `(By.X, "value")` tuples.
3. One method per user action, named as a verb phrase (`enter_mobile_number`, `click_get_otp`, `enter_otp`, `click_submit`, `enter_email`, `enter_password`, `click_login`).
4. Every method that waits for an element uses `WebDriverWait(self.driver, timeout).until(EC.<condition>)` — never a bare `find_element` without a wait guard on first use.
5. Methods return `self` for chaining unless they trigger navigation, in which case they return the next Page Object (or `None` with a comment if not yet built).
6. No assertions inside the Page Object — that's the test file's job.

## Output template
```python
# tests/pages/login_page.py
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    LOGIN_TRIGGER = (By.XPATH, "...")
    MOBILE_INPUT = (By.ID, "...")
    GET_OTP_BUTTON = (By.XPATH, "...")
    OTP_INPUT = (By.ID, "...")
    SUBMIT_BUTTON = (By.XPATH, "...")
    EMAIL_INPUT = (By.ID, "...")
    PASSWORD_INPUT = (By.ID, "...")
    ERROR_MESSAGE = (By.CSS_SELECTOR, "...")

    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open_login(self):
        self.wait.until(EC.element_to_be_clickable(self.LOGIN_TRIGGER)).click()
        return self

    def enter_mobile_number(self, number):
        self.wait.until(EC.visibility_of_element_located(self.MOBILE_INPUT)).send_keys(number)
        return self

    # ...remaining methods follow the same pattern
```
